import { GrillaPersonajes } from "../components/GrillaPersonajes/GrillaPersonajes";

export const LandingPage=()=>{
    return <GrillaPersonajes/>
}